DGK skills converted for Cognee Brain
=====================================

Cognee does not accept .skill (zip) files. These are Markdown (.md).

Upload all dgk-*.md files in Cognee Brain (dataset e.g. dgk-brain),
or POST each file to http://127.0.0.1:8000/api/v1/remember

Files:
- dgk-company-qualification.md
- dgk-content-system.md
- dgk-icp-to-outreach.md
- dgk-infographic-prompt.md
- dgk-lead-magnet-builder.md
- dgk-linkedin-system.md
- dgk-position-painpoint.md
- dgk-proposal-builder.md
- dgk-research.md
- dgk-sales-playbook.md
- dgk-signal-source.md
- dgk-visitor-intent.md
